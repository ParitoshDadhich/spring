# spring-data-jpa-springboot
This repository contains all the code developed and discussed on Dev2Prod Coding Spring Data Jpa | Springboot tutorials.
