package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	
	@Autowired
	private UserService service;

	@PostMapping("/login")
	@ResponseBody
	public String loginValid(@ModelAttribute Users users) {
		if(service.validUser(users.getUname(), users.getPass())) {
			return "Login successful!";
		}
		return "Login failed!";
	}


	@PostMapping("/register")
	@ResponseBody
//	public String registerUser(@RequestParam("uname")String uname,@RequestParam("pass")String pass,
//			@RequestParam("email")String email,@RequestParam("city")String city) {
	public String registerUser(@ModelAttribute Users users) {
		service.addUser(users);
	 
		return "welcome to Register";
		 
	}
	
	@GetMapping("/loadall")
	public List<Users> loadUsers(){
		return service.loadAll();
	}
	
	@GetMapping("/findUser/{name}")
	public String findUser(@PathVariable String name) {
		if(service.findUser(name)) {
			return name + " found!";
		}
		return name + " not found!";
	}

	@DeleteMapping("/deleteUser/{name}")
	public String deleteUser(@PathVariable String name) {
		if(service.deleteUser(name)) {
			return name + " foiunda and deleted!";
		}
		
		return "User not found";
	}
	
	@PutMapping("/updateUser/{name}")
	public String updateUser(@PathVariable String name, @RequestBody Users user) {
		if(service.updateUser(name, user)) {
			return "User updated!";
		}
		
		return "User not found!";
		
	}
}