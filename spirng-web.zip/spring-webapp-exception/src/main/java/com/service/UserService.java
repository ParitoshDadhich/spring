package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;

@Service
public class UserService {
	ArrayList<Users> al = new ArrayList<Users>();

	public void addUser(Users users) {

		al.add(users);
		System.out.println(al);
	}

	public boolean validUser(String uname, String pass) {

		if (uname.equals("admin") && pass.equals("manager")) {
			return true;
		}
		return false;
	}

	public List<Users> loadAll() {
		return al;
	}
	
	public boolean findUser(String name) {
		for(Users us: al) {
			if(us.getUname().equals(name)) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean deleteUser(String name) {
		for(Users us: al) {
			if(us.getUname().equals(name)) {
				al.remove(us);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateUser(String name, Users users) {
		for(Users us: al) {
			if(us.getUname().equals(name)) {
				// logic
				
				System.out.println(us);
				
				if(users.getUname() != null)
					us.setUname(users.getUname());
				
				if(users.getCity() != null)
					us.setCity(users.getCity());
				
				if(users.getEmail() != null)
					us.setCity(users.getEmail());
				
				if(users.getPass() != null)
						us.setPass(users.getPass());
				
				System.out.println("user updated!");
				System.out.println(us);
				return true;
			}
			else {
				System.out.println("User not found!");
			}
		}
		return false;
	}
}