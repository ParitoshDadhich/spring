package com.dao;

import org.springframework.stereotype.Repository;

import com.model.UserData;
import com.model.Users;

@Repository
public class UserDao {
	private static UserData list = new UserData();
	
	static {
		list.getUserList().add(new Users("alex", "alex123", "alex@gmail.com", "pune"));
		list.getUserList().add(new Users("mohan", "mohan123", "mohan@gmail.com", "mumbai"));
		list.getUserList().add(new Users("david", "david123", "david@gmail.com", "hyd"));
	}
	
	public UserData getAllUsers() {
		return list;
	}
	
	public void addUse(Users users) {
		list.getUserList().add(users);
	}
}
