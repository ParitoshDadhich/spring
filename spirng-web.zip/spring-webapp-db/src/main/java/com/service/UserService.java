package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UsersDao;
import com.model.Users;

@Service
public class UserService {
	ArrayList<Users> al= new ArrayList<Users>();
	
	@Autowired
	private UsersDao dao;
	
	public void addUser(Users users) {
		
		//al.add(users);
		dao.save(users);
		System.out.println(al);
	}
	public boolean loginValid(String uname,String pass) {
		if(uname.equals("admin") && pass.equals("manager")) {
			return true;
	}
		return false;
}
	public List<Users> loadAll(){
//		return al;
		return (ArrayList<Users>)dao.findAll();
	}
	
	public boolean findUser(int uid) {
//		for(Users us: al) {
//			if(us.getUname().equals(name)) {
//				return true;
//			}
//		}
		Optional<Users> data = dao.findById(uid);
		if(data.isPresent())
			return true;
		
		return false;
	}
	public boolean deleteUser(int uid) {
//		for(Users us: al) {
//			if(us.getUname().equals(name)) {
//				al.remove(us);
//				return true;
//			}
//		}
		
	Optional<Users> data = dao.findById(uid);
	if(data.isPresent()) {
		dao.deleteById(uid);
		return true;
	}
		return false;
	}
	
//	public boolean updateUser(String name,Users users) {
//		for(Users us: al) {
//			if(us.getUname().equals(name)) {
//				// write the logic 
//				
//				System.out.println("user updated...!");
//				return true;
//			}
//		}
//		System.out.println("user not found...!");
//		return false;
//	}
	
	public void updateUser(int uid,Users users) {
		 
		dao.updateUser(users.getUname(), users.getPass(), users.getEmail(), users.getCity(),uid);
		
	}
	
	
}

