package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	
	@Autowired
	private UserService service;

	@PostMapping("/login")
	@ResponseBody
	public String loginValid(@ModelAttribute Users users) {
		if(service.loginValid(users.getUname(), users.getPass())) {
			return "Login successful!";
		}
		return "Login failed!";
	}


	@PostMapping("/register")
	@ResponseBody
//	public String registerUser(@RequestParam("uname")String uname,@RequestParam("pass")String pass,
//			@RequestParam("email")String email,@RequestParam("city")String city) {
	public String registerUser(@ModelAttribute Users users) {
		service.addUser(users);
	 
		return "welcome to Register";
		 
	}
	
	@GetMapping("/loadall")
	public List<Users> loadUsers(){
		return service.loadAll();
	}
	
	@GetMapping("/findUser/{uid}")
	public String findUser(@PathVariable int uid) {
		if(service.findUser(uid)) {
			return uid + " found!";
		}
		return uid + " not found!";
	}

	@DeleteMapping("/deleteUser/{uid}")
	public String deleteUser(@PathVariable int uid) {
		if(service.deleteUser(uid)) {
			return uid + " foiunda and deleted!";
		}
		
		return "User not found";
	}
	
	@PutMapping("/updateuser/{id}")
	public String updateUser(@PathVariable int id,@RequestBody Users users) {
		 service.updateUser(id, users);
		 return "user updated";
	}
}